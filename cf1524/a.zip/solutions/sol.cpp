#include <bits/stdc++.h>
using namespace std;

const string C = "WR";

void solve() {
    int n, m; cin >> n >> m;
    string grid[n];
    for (auto i = 0; i < n; i++)
        cin >> grid[i];
    for (auto i = 0; i < 2; i++) {
        vector<string> ans(n, string(m, '.'));
        for (auto j = 0; j < n; j++) {
            for (auto k = 0; k < m; k++) {
                ans[j][k] = C[(j+k+i)%2];
            }
        }
        bool ok = true;
        for (auto j = 0; j < n; j++) {
            for (auto k = 0; k < m; k++) {
                ok &= grid[j][k] == '.' || grid[j][k] == ans[j][k];
            }
        }
        if (ok) {
            cout << ("yes") << '\n';
            for (auto j = 0; j < n; j++)
                cout << (ans[j]) << '\n';
            return;
        }
    }
    cout << ("no") << '\n';
}

int main() {

    int t; cin >> t;
    while (t--) {
        solve();
    }
}

