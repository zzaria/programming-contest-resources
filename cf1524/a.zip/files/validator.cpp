#include "testlib.h"

constexpr int MAXT = 100, MAXN = 50, MAXM = 50;

int main(int argc, char* argv[]) {
	registerValidation(argc, argv);
	int T = inf.readInt(1, MAXT, "number of test cases");
	inf.readEoln();

	for(auto t = 1; t <= T; t++){
		setTestCase(t);
		int n = inf.readInt(1, MAXN, "n");
		inf.readSpace();
		int m = inf.readInt(1, MAXM, "m");
		inf.readEoln();
	
		for(int i = 0; i < n; i++){
			for(int j = 0; j < m; j++){
				char c = inf.readChar();
				ensuref(c == 'R' or c == 'W' or c == '.', "Invalid character");
			}
			inf.readEoln();
		}
	}
	inf.readEof();
}
