#include "testlib.h"
#include <iostream>
#include <assert.h>
#define all(x) (x).begin(), (x).end()

#ifdef LOCAL
template<typename T> void pr(T a){std::cerr<<a<<std::endl;}
template<typename T, typename... Args> void pr(T a, Args... args){std::cerr<<a<<' ',pr(args...);}
#else
template<typename... Args> void pr(Args... args){}
#endif

using namespace std;


int main(int argc, char *argv[]) {
	registerGen(argc, argv, 1);
	
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cin.exceptions(cin.failbit);
	
	int t = atoi(argv[1]);
	int n = atoi(argv[2]);
	int m = atoi(argv[3]);
	int e = atoi(argv[4]);
	int p = atoi(argv[5]);
	assert(argc == 6);
	// number of cases, height, width, whether ans exists (1 or 2 for offset), probability of not being '.'
	cout<<t<<'\n';
	while(t--){
		cout<<n<<' '<<m<<'\n';

		char c[] = {'R', 'W'};

		for(int i = 0; i < n; i++){
			for(int j = 0; j < m; j++){
				if(rnd.next(0, 100) <= p){
					if(e){
						cout<<c[i+j+e&1];
					}
					else{
						cout<<c[rnd.next(0, 1)];
					}
				}
				else{
					cout<<'.';
				}
			}
			cout<<'\n';
		}
	}
}