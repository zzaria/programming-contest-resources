#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

std::string upper(std::string sa){
	for (size_t i = 0; i < sa.length(); i++)
		if ('a' <= sa[i] && sa[i] <= 'z')
			sa[i] = sa[i] - 'a' + 'A';
	return sa;
}

bool readAns(InStream &stream, int n, int m, vector<string> in)
{
	string ca = upper(stream.readToken());
	if (ca != "YES" && ca != "NO") stream.quitf(_wa, "expected YES nor NO, %s found", ca.c_str());
	if (ca == "NO") return false;

	vector<string> s(n);
	for(int i = 0; i < n; i++){
		s[i] = stream.readToken(format("[RW]{%d}", m));

		for(int j = 0; j < m; j++){
			if(in[i][j] != '.' and s[i][j] != in[i][j])
				stream.quitf(_wa, "recolored cell %d %d", i + 1, j + 1);

			if(i > 0 and s[i][j] == s[i-1][j])
				stream.quitf(_wa, "neighbouring cells (%d, %d) and (%d, %d) are of the same colour", i + 1, j + 1, i, j + 1);
			if(j > 0 and s[i][j] == s[i][j-1])
				stream.quitf(_wa, "neighbouring cells (%d, %d) and (%d, %d) are of the same colour", i + 1, j + 1, i + 1, j);
		}
	}
	return true;
}

int main(int argc, char *argv[]){
	setName("checker for problem a");
	registerTestlibCmd(argc, argv);

	int T = inf.readInt();
	for(int tc = 1; tc <= T; tc++){
		setTestCase(tc);

		int n = inf.readInt();
		int m = inf.readInt();
		vector<string> in(n), s(n), t(n);
		for(int i = 0; i < n; i++)
			in[i] = inf.readWord();
			
		bool ja = readAns(ans, n, m, in);
		bool pa = readAns(ouf, n, m, in);

		if (ja != pa)
		{
			if (ja && !pa) quitf(_wa, "valid grid exists, but contestant said NO");
			else quitf(_fail, "valid grid exists, but jury said NO");
		}
	}

	quit(_ok, "contestant's solution is correct");
}
