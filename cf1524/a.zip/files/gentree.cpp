#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;
template <class C> constexpr int sz(const C &c) { return int(c.size()); }
constexpr const char nl = '\n', sp = ' '; using uint = unsigned int;
using ll = long long; using ull = unsigned long long; using ld = long double;
#if __SIZEOF_INT128__
  using i128 = __int128_t; using ui128 = __uint128_t;
#endif

vector<string> gen(int N, int M, int H, int W, int code) {
  vector<string> G(N, string(M, '.'));
  for (int i = 0; i < H; i++) for (int j = 0; j < W; j++) {
    int v = code % 3;
    code /= 3;
    if (v == 1) G[i][j] = 'R';
    else if (v == 2) G[i][j] = 'W';
  }
  for (int i = 0; i < N; i++) for (int j = 0; j < M; j++) G[i][j] = G[i % H][j % W];
  return G;
}

vector<string> gen2(int N, int M, int type, int P, int flip) {
  vector<string> G(N, string(M, '.'));
  vector<tuple<int, int, int>> sorted;
  int midn = (N - 1) / 2, midm = (M - 1) / 2;
  for (int i = 0; i < N; i++) for (int j = 0; j < M; j++) {
    if (rnd.next(100) < P) G[i][j] = (i + j) % 2 == type ? 'R' : 'W';
    if (flip) sorted.emplace_back(abs(i - midn) + abs(j - midm), i, j);
  }
  if (flip > 0) {
    sort(sorted.begin(), sorted.end());
    for (auto &&[d, i, j] : sorted) if (G[i][j] != '.') {
      G[i][j] = G[i][j] == 'R' ? 'W' : 'R';
      if (--flip <= 0) break;
    }
  }
  return G;
}

int main(int argc, char *argv[]) {
  // freopen("in.txt", "r", stdin);
  // freopen("out.txt", "w", stdout);
  // freopen("err.txt", "w", stderr);
  registerGen(argc, argv, 1);
  ios::sync_with_stdio(0); cin.tie(0);
  vector<vector<string>> cases;
  for (int code = 0; code < 81; code++) cases.push_back(gen(50, 50, 2, 2, code));
  cases.push_back(gen2(50, 49, 0, 50, 0));
  cases.push_back(gen2(49, 50, 1, 50, 0));
  cases.push_back(gen2(49, 49, 0, 50, 0));
  cases.push_back(gen2(49, 49, 1, 50, 1));
  for (int code = 0; code < 3; code++) cases.push_back(gen(1, 1, 1, 1, code));
  for (int code : {1, 2, 3, 6, 5, 7}) {
    cases.push_back(gen(1, 2, 1, 2, code));
    cases.push_back(gen(2, 1, 2, 1, code));
  }
  shuffle(cases.begin(), cases.end());
  cout << sz(cases) << nl;
  for (auto &&G : cases) {
    cout << sz(G) << sp << sz(G[0]) << nl;
    for (auto && gi : G) cout << gi << nl;
  }
  return 0;
}
