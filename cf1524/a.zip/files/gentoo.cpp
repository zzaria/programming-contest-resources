#include "testlib.h"
#include <iostream>
#include <assert.h>
#define all(x) (x).begin(), (x).end()

#ifdef LOCAL
template<typename T> void pr(T a){std::cerr<<a<<std::endl;}
template<typename T, typename... Args> void pr(T a, Args... args){std::cerr<<a<<' ',pr(args...);}
#else
template<typename... Args> void pr(Args... args){}
#endif

using namespace std;


char c[] = {'R', 'W'};


int main(int argc, char *argv[]) {
	registerGen(argc, argv, 1);
	
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cin.exceptions(cin.failbit);

	vector<tuple<int, int, int, int>> v;
	int pv[] = {0, 20, 60, 100};
	array<int, 2> pp[] = {{1, 50}, {50, 1}, {50, 50}, {49, 50}, {50, 49}, {49, 49}};

	for(auto [n, m]: pp){
		for(auto p: pv){
			v.emplace_back(n, m, 0, p);
			v.emplace_back(n, m, 1, p);
		}
	}
	v.emplace_back(1, 50, -1, 50);
	v.emplace_back(1, 50, -1, 100);
	v.emplace_back(1, 50, -2, 50);
	v.emplace_back(1, 50, -2, 100);

	// only W/R and .
	v.emplace_back(50, 50, 3, 40);
	v.emplace_back(50, 50, 4, 40);

	// pr(size(v));

	while(size(v) < 99){
		int n = rnd.next(1, 50);
		int m = rnd.next(1, 50);
		int e = rnd.next(-2, 1);
		if(e < 0)
			e = rnd.next(-n*m/2, -1);
		
		int p = rnd.wnext(0, 100, -2);
		v.emplace_back(n, m, e, p);
	}

	int t = size(v);
	assert(t <= 100);
	cout<<t<<'\n';

	for(int tc = 0; tc < t; tc++){
		auto [n, m, e, p] = v[tc];
		// e = 0 means fix
		// e = 1,2 means freely choose colour (with 1/2 offset)
		// e = 3 means only 'W' and '.'
		// e = 4 means only 'R' and '.'
		// e < 0 means differ at exactly e locations

		cout<<n<<' '<<m<<'\n';

		vector<pair<int, int>> off;
		for(int i = 0; i < n; i++)
			for(int j = 0; j < m; j++)
				off.emplace_back(i, j);
		shuffle(all(off));

		set<pair<int, int>> st;
		int k = -e;
		if(e < 0){
			assert(k <= size(off));
			for(int i = 0; i < k; i++){
				st.insert(off[i]);
			}
		}

		for(int i = 0; i < n; i++){
			for(int j = 0; j < m; j++){

				if(rnd.next(0, 100) <= p){
					if(e == 4){
						char cc = c[i+j+e&1];
						if(cc == 'W') cc = '.';
						cout<<cc;
					}
					else if(e == 3){
						char cc = c[i+j+e&1];
						if(cc == 'R') cc = '.';
						cout<<cc;
					}
					else if(e == 2 or e == 1){
						cout<<c[i+j+e&1];
					}
					else if(e == 0){
						cout<<c[rnd.next(0, 1)];
					}
					else{
						cout<<c[i+j+st.count({i, j})&1];
					}
				}
				else{
					cout<<'.';
				}
			}
			cout<<'\n';
		}
	}
}