#include "testlib.h"
#include <iostream>
#include <cassert>
using namespace std;
using ll = long long;

const int MN = 4e5, MV = 1e9;

int main(int argc, char *argv[]) {
    registerGen(argc, argv, 1);

    cout << (1) << '\n';
    cout << (MN) << '\n';
    for (auto i = 0; i < MN; i++)
        cout << (i%2)*MV << " \n"[i == MN-1];
}
