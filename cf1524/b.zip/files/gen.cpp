#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

int main(int argc, char** argv){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cin.exceptions(cin.failbit);
    
    registerGen(argc, argv, 0);
    int t = atoi(argv[1]), sumn = atoi(argv[2]), minh = atoi(argv[3]), maxh = atoi(argv[4]);
    assert(t <= sumn);
    sumn -= t;
    cout<<t<<'\n';
    while(t--){
        int n = rnd.next(0, sumn);
        if(!t) n = sumn;
        sumn -= n;
        n++;
        cout<<n<<'\n';
        for(int i = 1; i <= n; i++){
            cout<<rnd.next(minh, maxh)<<" \n"[i==n];
        }
    }
}
/*
things to do:
pretest 2 small cases
pretest 3 max
pretest 4 random
main tests

*/