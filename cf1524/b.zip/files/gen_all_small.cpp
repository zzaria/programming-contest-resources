#include "testlib.h"
#include <iostream>
#include <cassert>
using namespace std;
using ll = long long;

const int MV = 5, MN = 101;
int a[MN];
void rec(int c, int n) {
    if (c == n) {
        cout << (n) << '\n';
        for (auto i = 0; i < n; i++) cout << a[i] << " \n"[i == n-1];
        return;
    }

    for (auto i = 0; i <= MV; i++) {
        a[c] = i;
        rec(c+1, n);
    }
}

int main(int argc, char *argv[]) {
    registerGen(argc, argv, 1);

    int lim = atoi(argv[1]), tc = 0;
    for (auto i = 1; i <= lim; i++) {
        int p = 1;
        for (auto j = 0; j < i; j++) p *= 6;
        tc += p;
    }

    cout << (tc) << '\n';
    for (auto i = 1; i <= lim; i++) {
        rec(0, i);
    }
}
