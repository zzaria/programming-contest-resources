#include "testlib.h"
#include <iostream>
#include <cassert>
using namespace std;
using ll = long long;

int minv, maxv;

vector<int> makeArr(int n, int sum, int req) {
    vector<int> res(n, req);
    sum -= n*req;
    vector<int> p{0};
    for (auto i = 0; i < n-1; i++)
        p.push_back(rnd.next(0, sum));
    p.push_back(sum);
    sort(p.begin(), p.end());
    for (auto i = 0; i < n; i++)
        res[i] += p[i+1]-p[i];
    return res;
}

void make(int n) {
    cout << (n) << '\n';
    for (auto i = 0; i < n; i++)
        cout << rnd.next(minv, maxv) << " \n"[i == n-1];
}

int main(int argc, char *argv[]) {
    registerGen(argc, argv, 1);

    int tc = stoi(argv[1]), totN = stoi(argv[2]);
    minv = stoi(argv[3]), maxv = stoi(argv[4]);
    assert(tc <= totN);

    cout << tc << '\n';
    for (auto n : makeArr(tc, totN, 1))
        make(n);
}
