#include <bits/stdc++.h>
#include "testlib.h"
using namespace std;
int main(int argc, char* argv[]){
    registerValidation(argc, argv);
    int t = inf.readInt(1, 1e4, "t");
    inf.readEoln();
    int sum=0;
    for (auto tc = 1; tc <= t; tc++) {
        setTestCase(tc);
	    int n = inf.readInt(1, 4e5, "n");
	    inf.readEoln();
	    sum+=n;
	    ensuref(sum<=4e5,"Sum of N must be at most 400000");
	    for(int i = 1; i <= n; i++){
	        inf.readInt(0, 1e9, "a_i");
	        if(i == n) inf.readEoln();
	        else inf.readSpace();
	    }
    }
    inf.readEof();
}
