#include <bits/stdc++.h>
#define all(x) (x).begin(), (x).end()

#ifdef LOCAL
template<typename T> void pr(T a){std::cerr<<a<<std::endl;}
template<typename T,typename... Args> void pr(T a, Args... args) {std::cerr<<a<<' ',pr(args...);}
#else
template<typename... Args> void pr(Args... args){}
#endif

using namespace std;
using ll = long long;
const int MM = 4e5+5;

int t, n, a[MM], b[MM];

int main(){
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cin.exceptions(cin.failbit);
	
	cin>>t;
	while(t--){
		ll ans = 0;
		cin>>n;
		for(int i = 1; i <= n; i++){
			cin>>a[i];
		}
		a[n+1] = 0;
		b[n+1] = 0;
		for(int i = 1; i <= n; i++){
			b[i] = min(a[i], max(a[i-1], a[i+1]));
		}
		for(int i = 1; i <= n; i++){
			ans += a[i]-b[i];
			ans += max(0, b[i]-b[i-1]);
			ans += max(0, b[i]-b[i+1]);
		}
		cout<<ans<<'\n';
	}
}