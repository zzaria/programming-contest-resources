import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class B {

	public static void main(String[] args) throws IOException {
		int T = readInt();
		while (T-- > 0) {
			int n = readInt();
			int[] a = new int[n+2];
			for (int i = 1; i <= n; i++) a[i] = readInt();
			long ans = 0;
			for (int i = 1; i <= n; i++) {
				int req = Math.max(a[i-1], a[i+1]);
				if (a[i] > req) {
					ans += a[i] - req;
					a[i] = req;
				}
			}
			for (int i = 1; i <= n+1; i++) ans += Math.abs(a[i-1] - a[i]);
			System.out.println(ans);
		}
	}
	
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
    static String next() throws IOException {
    	while (st == null || !st.hasMoreTokens()) st = new StringTokenizer(br.readLine().trim());
    	return st.nextToken();
    }
    static long readLong() throws IOException {
    	return Long.parseLong(next());
	}
    static int readInt() throws IOException {
    	return Integer.parseInt(next());
    }
    static short readShort() throws IOException{
    	return Short.parseShort(next());
    }
    static double readDouble() throws IOException {
        return Double.parseDouble(next());
    }
    static char readCharacter() throws IOException {
        return next().charAt(0);
    }
    static String readLine() throws IOException {
        return br.readLine().trim();
    }
}
