t=int(input())
arr=[0]*int(4e5+2)
for test in range(t):
    n=int(input())
    arr[n+1]=0
    te=list(map(int,input().split()))
    for i in range(1,n+1):
        arr[i]=te[i-1]
    ans=0
    for i in range(1,n+1):
        should = min(arr[i], max(arr[i - 1], arr[i + 1]))
        ans += arr[i] - should + abs(should - arr[i - 1])
        arr[i] = should
    print(ans+arr[n])