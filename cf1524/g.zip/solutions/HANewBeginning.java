import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.PriorityQueue;
import java.util.StringTokenizer;

public class HANewBeginning {
	static final int MN = 800010;
	static long n = 0, x = 0, y = 0, a = 0, b = 0, c, d, ans = 0;
	static String ff;

	public static void main(String[] args) throws IOException {
		ArrayList<Pair<Long, Long>> p = new ArrayList<>();
		PriorityQueue<Long> pa = new PriorityQueue<>(1, Collections.reverseOrder());
		PriorityQueue<Long> pb = new PriorityQueue<>(); // min queue
		n = readInt();
		for (int i = 0; i < n; i++) {
			x = readInt(); y = readInt();
			p.add(new Pair<Long, Long>(x+y, x-y));
		}
		Collections.sort(p); pa.add((long) 0); pb.add((long) 0);
		for (Pair<Long, Long> pp : p) {
			long x = pp.s, y = pp.f;
			ans += Math.max(Math.max(pa.peek()-y-x,x-pb.peek()-y), 0);
			if(pa.isEmpty() || pb.peek()+y>x){
				pa.add(x+y); pa.add(x+y); pb.add(pa.peek()-2*y); pa.poll();
			}
			else{
				pb.add(x-y); pb.add(x-y); pa.add(pb.peek()+2*y); pb.poll();
			}
		}
		ans/=2;
		System.out.println(ans);
	}
	
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
    static String next() throws IOException {
    	while (st == null || !st.hasMoreTokens()) st = new StringTokenizer(br.readLine().trim());
    	return st.nextToken();
    }
    static long readLong() throws IOException {
    	return Long.parseLong(next());
	}
    static int readInt() throws IOException {
    	return Integer.parseInt(next());
    }
    static short readShort() throws IOException{
    	return Short.parseShort(next());
    }
    static double readDouble() throws IOException {
        return Double.parseDouble(next());
    }
    static char readCharacter() throws IOException {
        return next().charAt(0);
    }
    static String readLine() throws IOException {
        return br.readLine().trim();
    }
    
    static class Pair<T extends Comparable<T>, U extends Comparable<U>> implements Comparable<Pair<T, U>> {
    	T f;
    	U s;
    	public Pair(T f0, U s0) {
    		f = f0;
    		s = s0;
    	}
    	
		@Override
		public int compareTo(Pair<T, U> o) {
			int fc = f.compareTo(o.f);
			return fc == 0 ? s.compareTo(o.s) : fc;
		}
    }
}