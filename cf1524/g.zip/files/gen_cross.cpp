#include "testlib.h"
#include <iostream>
#include <cassert>
using namespace std;
using ll = long long;
using pii = pair<int, int>;

vector<pii> pts;

int main(int argc, char *argv[]) {
    registerGen(argc, argv, 1);

    int N = atoi(argv[1]), M = atoi(argv[2]), p1 = atoi(argv[3]), p2 = atoi(argv[4]);

    for (auto i = 0; i < N; i++) {
        int q = rnd.next(0, M);
        if (rnd.next(1, p1+p2) <= p1)
            pts.emplace_back(q, q);
        else 
            pts.emplace_back(q, M-q);
    }

    // print
    cout << (N) << '\n';
    shuffle(pts.begin(), pts.end());
    for (auto [a, b] : pts) cout << (a) << ' ' << (b) << '\n';
}
