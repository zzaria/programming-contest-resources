#include "testlib.h"
#include <iostream>
#include <cassert>
using namespace std;
using ll = long long;
using pii = pair<int, int>;

vector<pii> pts;

// diagonals:
// y=x+b
// vary: -M, M
//
// x+b >= 0
// x >= -b
//
// x+b <= M
// x <= M-b
//
// antidiagonals:
// y=b-x
// vary: 0, 2*M
//
// b-x >= 0
// -x >= -b
// x <= b
//
// b-x <= M
// -x <= M-b
// x >= b-M
int main(int argc, char *argv[]) {
    registerGen(argc, argv, 1);

    // d_or_a -> 0 for x, 1 for y
    // isext -> isextreme
    int N = atoi(argv[1]), M = atoi(argv[2]), dora = atoi(argv[3]), cnt = atoi(argv[4]), isext = atoi(argv[5]);
    vector<int> cs;
    for (auto i = 0; i < cnt; i++) {
        if (!dora) cs.push_back(rnd.next(-M, M));
        else cs.push_back(rnd.next(0, 2*M));
    }

    for (auto i = 0; i < N; i++) {
        int b = cs[rnd.next(0, cnt-1)], minx, maxx, x;
        if (!dora) {
            minx = -b;
            maxx = M-b;
        }
        else {
            minx = b-M;
            maxx = b;
        }
        minx = max(minx, 0);
        maxx = min(maxx, M);

        if (isext) {
            int m = -1 + 2*rnd.next(0, 1);
            x = rnd.wnext(minx, maxx, m*40);
        }
        else x = rnd.next(minx, maxx);

        int y = !dora ? x+b : b-x;
        pts.emplace_back(x, y);
    }

    // print
    cout << (N) << '\n';
    shuffle(pts.begin(), pts.end());
    for (auto [a, b] : pts) cout << (a) << ' ' << (b) << '\n';
}
