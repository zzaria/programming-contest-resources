#include "testlib.h"
#include <bits/stdc++.h>

int N=8e5,M=1e9; //8e5

int main(int argc, char* argv[]){
    registerValidation(argc, argv);
    int n = inf.readInt(1,N,"n");
    inf.readEoln();
    for (int i = 0; i < n; i++){
        inf.readInt(0,M,"x");
        inf.readSpace();
        inf.readInt(0,M,"y");
        inf.readEoln();
    }
    inf.readEof();
    return 0;
}
