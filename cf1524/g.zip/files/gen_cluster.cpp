#include "testlib.h"
#include <iostream>
#include <cassert>
using namespace std;
using ll = long long;
using pii = pair<int, int>;

vector<int> makeArr(int n, int sum, int req) {
    vector<int> res(n, req);
    sum -= n*req;
    vector<int> p{0};
    for (auto i = 0; i < n-1; i++)
        p.push_back(rnd.next(0, sum));
    p.push_back(sum);
    sort(p.begin(), p.end());
    for (auto i = 0; i < n; i++)
        res[i] += p[i+1]-p[i];
    return res;
}

vector<pii> pts;

int main(int argc, char *argv[]) {
    registerGen(argc, argv, 1);

    // 0 for x, 1 for y
    int N = atoi(argv[1]), M = atoi(argv[2]), cnt = atoi(argv[3]), range = atoi(argv[4]);

    for (auto n : makeArr(cnt, N, 1)) {
        int cx = rnd.next(range, M-range), cy = rnd.next(range, M-range);
        for (auto i = 0; i < n; i++)
            pts.emplace_back(rnd.next(cx-range, cx+range), rnd.next(cy-range, cy+range));
    }

    // print
    cout << (N) << '\n';
    shuffle(pts.begin(), pts.end());
    for (auto [a, b] : pts) cout << (a) << ' ' << (b) << '\n';
}
