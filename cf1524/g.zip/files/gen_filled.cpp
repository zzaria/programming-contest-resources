#include "testlib.h"
#include <iostream>
#include <cassert>
using namespace std;
using ll = long long;
using pii = pair<int, int>;

vector<pii> pts;

int main(int argc, char *argv[]) {
    registerGen(argc, argv, 1);

    int N = atoi(argv[1]);
    for (auto i = 0; i < N; i++){
        for (auto j = 0; j < N; j++){
            pts.emplace_back(i, j);
        }
    }

    // print
    cout << pts.size() << '\n';
    shuffle(pts.begin(), pts.end());
    for (auto [a, b] : pts) cout << (a) << ' ' << (b) << '\n';
}
