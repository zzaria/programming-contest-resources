#include "testlib.h"
#include <iostream>
#include <cassert>
using namespace std;
using ll = long long;
using pii = pair<int, int>;

vector<pii> pts;

int main(int argc, char *argv[]) {
    registerGen(argc, argv, 1);

    // 0 for x, 1 for y
    // isext -> isextreme
    int N = atoi(argv[1]), M = atoi(argv[2]), xory = atoi(argv[3]), cnt = atoi(argv[4]), isext = atoi(argv[5]);
    vector<int> cs;
    for (auto i = 0; i < cnt; i++)
        cs.push_back(rnd.next(0, M));

    for (auto i = 0; i < N; i++) {
        int x = cs[rnd.next(0, cnt-1)], y = rnd.next(0, M);
        if (isext) {
            int m = -1 + 2*rnd.next(0, 1);
            y = rnd.wnext(0, M, m*40);
        }
        if (xory) swap(x, y);
        pts.emplace_back(x, y);
    }

    // print
    cout << (N) << '\n';
    shuffle(pts.begin(), pts.end());
    for (auto [a, b] : pts) cout << (a) << ' ' << (b) << '\n';
}
