#include <bits/stdc++.h>
#include "testlib.h"
#define all(x) (x).begin(), (x).end()

#ifdef LOCAL
template<typename T> void pr(T a){std::cerr<<a<<std::endl;}
template<typename T, typename... Args> void pr(T a, Args... args){std::cerr<<a<<' ',pr(args...);}
#else
template<typename... Args> void pr(Args... args){}
#endif

using namespace std;
constexpr int MM = 500*2;

int n, m;
int sum[MM];
char c[MM][MM];

int main(int argc, char* argv[]){
	// n = m = size of grid
	// k = # of different rectangles (the rectangles might intersect), have k = 1 to avoid
	// l = length of each rectangle
	// extra arguments seed the random generator
	assert(argc >= 3);
	n = m = atoi(argv[1]);
	int k = atoi(argv[2]);
	int l = atoi(argv[3]);

	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cin.exceptions(cin.failbit);
	registerGen(argc, argv, 0);

	memset(c, '.', sizeof c);

	for(int f = 0; f < k; f++){
		int x = rnd.next(0, n-l);
		int y = rnd.next(0, m-l);
		for(int i = 1; i < l-1; i++){
			c[x+i][y] = c[x][y+i] = '#';
			c[x+i][y+l-1] = c[x+l-1][y+i] = '#';
		}

		x += 2;
		y += 2;
		l -= 4;
		for(int i = 1; i < l-1; i++){
			c[x+i][y] = c[x][y+i] = '#';
			c[x+i][y+l-1] = c[x+l-1][y+i] = '#';
		}
	}

	cout<<n<<' '<<m<<'\n';
	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			cout<<c[i][j];
			sum[j] += c[i][j] == '#';
		}
		cout<<'\n';
	}

	for(int i = 0; i < m; i++){
		cout<<sum[i]<<" \n"[i+1==m];
	}
}
/*

This case is

###########
#.........#
#...##....#
#..#..#...#
#...##....#
#.........#
###########

rectangle a rectangle inside

*/