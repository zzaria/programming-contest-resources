#include <bits/stdc++.h>
#include "testlib.h"
#define all(x) (x).begin(), (x).end()

#ifdef LOCAL
template<typename T> void pr(T a){std::cerr<<a<<std::endl;}
template<typename T, typename... Args> void pr(T a, Args... args){std::cerr<<a<<' ',pr(args...);}
#else
template<typename... Args> void pr(Args... args){}
#endif

using namespace std;
constexpr int MM = 500*2;

int n, m;
int sum[MM];
char c[MM][MM];

int main(int argc, char* argv[]){
	// n = m = size of grid
	// k = # of different rectangles (the rectangles might intersect), have k = 1 to avoid
	// extra arguments seed the random generator
	assert(argc >= 2);
	n = m = atoi(argv[1]);
	int k = atoi(argv[2]);

	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cin.exceptions(cin.failbit);
	registerGen(argc, argv, 0);

	memset(c, '.', sizeof c);

	for(int f = 0; f < k; f++){
		int hl = rnd.next(2, m-3);
		int vl = rnd.next(1, n-3);

		int x = rnd.next(0, m-1-hl);
		int y = rnd.next(2, n-1-vl);

		for(int i = x; i < x+hl; i++)
			c[y][i] = '#';

		int mid = rnd.next(x, x+hl-2);
		for(int i = mid; i < x+hl+1; i++)
			c[y-2][i] = '#';

		for(int i = y-1; i < y+vl; i++)
			c[i][x+hl+1] = '#';
	}

	for(int i = 0; i < n/2; i++){
		for(int j = 0; j < m; j++){
			swap(c[i][j], c[n-1-i][j]);
		}
	}

	cout<<n<<' '<<m<<'\n';
	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			cout<<c[i][j];
			sum[j] += c[i][j] == '#';
		}
		cout<<'\n';
	}

	for(int i = 0; i < m; i++){
		cout<<sum[i]<<" \n"[i+1==m];
	}
}
/*

This case is


........#
######..#
........#
....####.


*/