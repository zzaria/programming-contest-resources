#!/usr/bin/env bash
#   *** validation ***
scripts/run-validator-tests.sh
scripts/run-checker-tests.sh

#    *** tests ***
mkdir -p tests
echo "Generating test #5"
scripts/gen-input-via-stdout.sh "wine files/gen_rect_in_rect.exe 632 1 69" "tests/05" 5
echo "Generating test #6"
scripts/gen-input-via-stdout.sh "wine files/gen_rect_in_rect.exe 632 10 69" "tests/06" 6
echo "Generating test #7"
scripts/gen-input-via-stdout.sh "wine files/gen_rect_in_rect.exe 632 1000 69" "tests/07" 7
echo "Generating test #8"
scripts/gen-input-via-stdout.sh "wine files/gen_L_shape.exe 632 1" "tests/08" 8
echo "Generating test #9"
scripts/gen-input-via-stdout.sh "wine files/gen_L_shape.exe 632 10" "tests/09" 9
echo "Generating test #10"
scripts/gen-input-via-stdout.sh "wine files/gen_L_shape.exe 632 1000 seed" "tests/10" 10
echo "Generating test #11"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 5 80000 40 3" "tests/11" 11
echo "Generating test #12"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 1 400000 40 3" "tests/12" 12
echo "Generating test #13"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 1 400000 100 3" "tests/13" 13
echo "Generating test #14"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 50 8000 100 3" "tests/14" 14
echo "Generating test #15"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 632 632 100 3" "tests/15" 15
echo "Generating test #16"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 400000 1 100 3" "tests/16" 16
echo "Generating test #17"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 1 400000 0 3" "tests/17" 17
echo "Generating test #18"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 632 632 0 3" "tests/18" 18
echo "Generating test #19"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 1 50 1" "tests/19" 19
echo "Generating test #20"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 1 97 1" "tests/20" 20
echo "Generating test #21"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 2 50 1" "tests/21" 21
echo "Generating test #22"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 3 20 1" "tests/22" 22
echo "Generating test #23"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 3 50 1" "tests/23" 23
echo "Generating test #24"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 3 97 1" "tests/24" 24
echo "Generating test #25"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 5 50 1" "tests/25" 25
echo "Generating test #26"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 3 50 1" "tests/26" 26
echo "Generating test #27"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 5 50 1" "tests/27" 27
echo "Generating test #28"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 501 314 0 3" "tests/28" 28
echo "Generating test #29"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 1 1 0 3" "tests/29" 29
echo "Generating test #30"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 1 1 100 3" "tests/30" 30
echo "Generating test #31"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 8000 50 100 3" "tests/31" 31
echo "Generating test #32"
scripts/gen-input-via-stdout.sh "wine files/gen_rect_in_rect.exe 632 5 69" "tests/32" 32
echo "Generating test #33"
scripts/gen-input-via-stdout.sh "wine files/gen_rect_in_rect.exe 632 100 69" "tests/33" 33
echo "Generating test #34"
scripts/gen-input-via-stdout.sh "wine files/gen_L_shape.exe 632 5" "tests/34" 34
echo "Generating test #35"
scripts/gen-input-via-stdout.sh "wine files/gen_L_shape.exe 632 100" "tests/35" 35
echo "Generating test #36"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5 80000 5 99 1" "tests/36" 36
echo "Generating test #37"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 1 400000 5 99 1" "tests/37" 37
echo "Generating test #38"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80000 5 5 99 1" "tests/38" 38
echo "Generating test #39"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 400000 1 5 99 1" "tests/39" 39
echo "Generating test #40"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80000 5 5 40 1" "tests/40" 40
echo "Generating test #41"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 400000 1 5 40 1" "tests/41" 41
echo "Generating test #42"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 100 4000 5 40 1" "tests/42" 42
echo "Generating test #43"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 100 4000 5 99 1" "tests/43" 43
echo "Generating test #44"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 50 8000 5 40 1" "tests/44" 44
echo "Generating test #45"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 50 8000 5 99 1" "tests/45" 45
echo "Generating test #46"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 4000 100 5 40 1" "tests/46" 46
echo "Generating test #47"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 4000 100 5 99 1" "tests/47" 47
echo "Generating test #48"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 8000 50 5 40 1" "tests/48" 48
echo "Generating test #49"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 8000 50 5 99 1" "tests/49" 49
echo "Generating test #50"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 5 80000 0 3" "tests/50" 50
echo "Generating test #51"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 20 20000 0 3" "tests/51" 51
echo "Generating test #52"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 1 5 1" "tests/52" 52
echo "Generating test #53"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 1 20 1" "tests/53" 53
echo "Generating test #54"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 2 5 1" "tests/54" 54
echo "Generating test #55"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 2 20 1" "tests/55" 55
echo "Generating test #56"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 2 97 1" "tests/56" 56
echo "Generating test #57"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 3 5 1" "tests/57" 57
echo "Generating test #58"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 5 5 1" "tests/58" 58
echo "Generating test #59"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 5 20 1" "tests/59" 59
echo "Generating test #60"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 5 97 1" "tests/60" 60
echo "Generating test #61"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80 5000 1 5 1" "tests/61" 61
echo "Generating test #62"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80 5000 1 20 1" "tests/62" 62
echo "Generating test #63"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80 5000 1 50 1" "tests/63" 63
echo "Generating test #64"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80 5000 1 97 1" "tests/64" 64
echo "Generating test #65"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80 5000 2 5 1" "tests/65" 65
echo "Generating test #66"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80 5000 2 20 1" "tests/66" 66
echo "Generating test #67"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80 5000 2 50 1" "tests/67" 67
echo "Generating test #68"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80 5000 2 97 1" "tests/68" 68
echo "Generating test #69"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80 5000 3 5 1" "tests/69" 69
echo "Generating test #70"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80 5000 3 20 1" "tests/70" 70
echo "Generating test #71"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80 5000 3 50 1" "tests/71" 71
echo "Generating test #72"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80 5000 3 97 1" "tests/72" 72
echo "Generating test #73"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80 5000 5 5 1" "tests/73" 73
echo "Generating test #74"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80 5000 5 20 1" "tests/74" 74
echo "Generating test #75"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80 5000 5 50 1" "tests/75" 75
echo "Generating test #76"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 80 5000 5 97 1" "tests/76" 76
echo "Generating test #77"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 1 5 1" "tests/77" 77
echo "Generating test #78"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 1 20 1" "tests/78" 78
echo "Generating test #79"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 1 50 1" "tests/79" 79
echo "Generating test #80"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 1 97 1" "tests/80" 80
echo "Generating test #81"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 2 5 1" "tests/81" 81
echo "Generating test #82"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 2 20 1" "tests/82" 82
echo "Generating test #83"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 2 50 1" "tests/83" 83
echo "Generating test #84"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 2 97 1" "tests/84" 84
echo "Generating test #85"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 3 5 1" "tests/85" 85
echo "Generating test #86"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 3 20 1" "tests/86" 86
echo "Generating test #87"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 3 97 1" "tests/87" 87
echo "Generating test #88"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 5 5 1" "tests/88" 88
echo "Generating test #89"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 5 20 1" "tests/89" 89
echo "Generating test #90"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 5 97 1" "tests/90" 90
echo "Generating test #91"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 1 400000 20 3" "tests/91" 91
echo "Generating test #92"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 1 400000 80 3" "tests/92" 92
echo "Generating test #93"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 50 8000 20 3" "tests/93" 93
echo "Generating test #94"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 50 8000 60 3" "tests/94" 94
echo "Generating test #95"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 632 632 1 3" "tests/95" 95
echo "Generating test #96"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 632 632 20 3" "tests/96" 96
echo "Generating test #97"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 632 632 40 3" "tests/97" 97
echo "Generating test #98"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 632 632 60 3" "tests/98" 98
echo "Generating test #99"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 632 632 80 3" "tests/99" 99
echo "Generating test #100"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 632 632 99 3" "tests/100" 100
echo "Generating test #101"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 8000 50 40 3" "tests/101" 101
echo "Generating test #102"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 8000 50 80 3" "tests/102" 102
echo "Generating test #103"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 400000 1 20 3" "tests/103" 103
echo ""
echo "Generating answer for test #1"
scripts/gen-answer.sh tests/01 tests/01.a "tests" ""
echo ""
echo "Generating answer for test #2"
scripts/gen-answer.sh tests/02 tests/02.a "tests" ""
echo ""
echo "Generating answer for test #3"
scripts/gen-answer.sh tests/03 tests/03.a "tests" ""
echo ""
echo "Generating answer for test #4"
scripts/gen-answer.sh tests/04 tests/04.a "tests" ""
echo ""
echo "Generating answer for test #5"
scripts/gen-answer.sh tests/05 tests/05.a "tests" ""
echo ""
echo "Generating answer for test #6"
scripts/gen-answer.sh tests/06 tests/06.a "tests" ""
echo ""
echo "Generating answer for test #7"
scripts/gen-answer.sh tests/07 tests/07.a "tests" ""
echo ""
echo "Generating answer for test #8"
scripts/gen-answer.sh tests/08 tests/08.a "tests" ""
echo ""
echo "Generating answer for test #9"
scripts/gen-answer.sh tests/09 tests/09.a "tests" ""
echo ""
echo "Generating answer for test #10"
scripts/gen-answer.sh tests/10 tests/10.a "tests" ""
echo ""
echo "Generating answer for test #11"
scripts/gen-answer.sh tests/11 tests/11.a "tests" ""
echo ""
echo "Generating answer for test #12"
scripts/gen-answer.sh tests/12 tests/12.a "tests" ""
echo ""
echo "Generating answer for test #13"
scripts/gen-answer.sh tests/13 tests/13.a "tests" ""
echo ""
echo "Generating answer for test #14"
scripts/gen-answer.sh tests/14 tests/14.a "tests" ""
echo ""
echo "Generating answer for test #15"
scripts/gen-answer.sh tests/15 tests/15.a "tests" ""
echo ""
echo "Generating answer for test #16"
scripts/gen-answer.sh tests/16 tests/16.a "tests" ""
echo ""
echo "Generating answer for test #17"
scripts/gen-answer.sh tests/17 tests/17.a "tests" ""
echo ""
echo "Generating answer for test #18"
scripts/gen-answer.sh tests/18 tests/18.a "tests" ""
echo ""
echo "Generating answer for test #19"
scripts/gen-answer.sh tests/19 tests/19.a "tests" ""
echo ""
echo "Generating answer for test #20"
scripts/gen-answer.sh tests/20 tests/20.a "tests" ""
echo ""
echo "Generating answer for test #21"
scripts/gen-answer.sh tests/21 tests/21.a "tests" ""
echo ""
echo "Generating answer for test #22"
scripts/gen-answer.sh tests/22 tests/22.a "tests" ""
echo ""
echo "Generating answer for test #23"
scripts/gen-answer.sh tests/23 tests/23.a "tests" ""
echo ""
echo "Generating answer for test #24"
scripts/gen-answer.sh tests/24 tests/24.a "tests" ""
echo ""
echo "Generating answer for test #25"
scripts/gen-answer.sh tests/25 tests/25.a "tests" ""
echo ""
echo "Generating answer for test #26"
scripts/gen-answer.sh tests/26 tests/26.a "tests" ""
echo ""
echo "Generating answer for test #27"
scripts/gen-answer.sh tests/27 tests/27.a "tests" ""
echo ""
echo "Generating answer for test #28"
scripts/gen-answer.sh tests/28 tests/28.a "tests" ""
echo ""
echo "Generating answer for test #29"
scripts/gen-answer.sh tests/29 tests/29.a "tests" ""
echo ""
echo "Generating answer for test #30"
scripts/gen-answer.sh tests/30 tests/30.a "tests" ""
echo ""
echo "Generating answer for test #31"
scripts/gen-answer.sh tests/31 tests/31.a "tests" ""
echo ""
echo "Generating answer for test #32"
scripts/gen-answer.sh tests/32 tests/32.a "tests" ""
echo ""
echo "Generating answer for test #33"
scripts/gen-answer.sh tests/33 tests/33.a "tests" ""
echo ""
echo "Generating answer for test #34"
scripts/gen-answer.sh tests/34 tests/34.a "tests" ""
echo ""
echo "Generating answer for test #35"
scripts/gen-answer.sh tests/35 tests/35.a "tests" ""
echo ""
echo "Generating answer for test #36"
scripts/gen-answer.sh tests/36 tests/36.a "tests" ""
echo ""
echo "Generating answer for test #37"
scripts/gen-answer.sh tests/37 tests/37.a "tests" ""
echo ""
echo "Generating answer for test #38"
scripts/gen-answer.sh tests/38 tests/38.a "tests" ""
echo ""
echo "Generating answer for test #39"
scripts/gen-answer.sh tests/39 tests/39.a "tests" ""
echo ""
echo "Generating answer for test #40"
scripts/gen-answer.sh tests/40 tests/40.a "tests" ""
echo ""
echo "Generating answer for test #41"
scripts/gen-answer.sh tests/41 tests/41.a "tests" ""
echo ""
echo "Generating answer for test #42"
scripts/gen-answer.sh tests/42 tests/42.a "tests" ""
echo ""
echo "Generating answer for test #43"
scripts/gen-answer.sh tests/43 tests/43.a "tests" ""
echo ""
echo "Generating answer for test #44"
scripts/gen-answer.sh tests/44 tests/44.a "tests" ""
echo ""
echo "Generating answer for test #45"
scripts/gen-answer.sh tests/45 tests/45.a "tests" ""
echo ""
echo "Generating answer for test #46"
scripts/gen-answer.sh tests/46 tests/46.a "tests" ""
echo ""
echo "Generating answer for test #47"
scripts/gen-answer.sh tests/47 tests/47.a "tests" ""
echo ""
echo "Generating answer for test #48"
scripts/gen-answer.sh tests/48 tests/48.a "tests" ""
echo ""
echo "Generating answer for test #49"
scripts/gen-answer.sh tests/49 tests/49.a "tests" ""
echo ""
echo "Generating answer for test #50"
scripts/gen-answer.sh tests/50 tests/50.a "tests" ""
echo ""
echo "Generating answer for test #51"
scripts/gen-answer.sh tests/51 tests/51.a "tests" ""
echo ""
echo "Generating answer for test #52"
scripts/gen-answer.sh tests/52 tests/52.a "tests" ""
echo ""
echo "Generating answer for test #53"
scripts/gen-answer.sh tests/53 tests/53.a "tests" ""
echo ""
echo "Generating answer for test #54"
scripts/gen-answer.sh tests/54 tests/54.a "tests" ""
echo ""
echo "Generating answer for test #55"
scripts/gen-answer.sh tests/55 tests/55.a "tests" ""
echo ""
echo "Generating answer for test #56"
scripts/gen-answer.sh tests/56 tests/56.a "tests" ""
echo ""
echo "Generating answer for test #57"
scripts/gen-answer.sh tests/57 tests/57.a "tests" ""
echo ""
echo "Generating answer for test #58"
scripts/gen-answer.sh tests/58 tests/58.a "tests" ""
echo ""
echo "Generating answer for test #59"
scripts/gen-answer.sh tests/59 tests/59.a "tests" ""
echo ""
echo "Generating answer for test #60"
scripts/gen-answer.sh tests/60 tests/60.a "tests" ""
echo ""
echo "Generating answer for test #61"
scripts/gen-answer.sh tests/61 tests/61.a "tests" ""
echo ""
echo "Generating answer for test #62"
scripts/gen-answer.sh tests/62 tests/62.a "tests" ""
echo ""
echo "Generating answer for test #63"
scripts/gen-answer.sh tests/63 tests/63.a "tests" ""
echo ""
echo "Generating answer for test #64"
scripts/gen-answer.sh tests/64 tests/64.a "tests" ""
echo ""
echo "Generating answer for test #65"
scripts/gen-answer.sh tests/65 tests/65.a "tests" ""
echo ""
echo "Generating answer for test #66"
scripts/gen-answer.sh tests/66 tests/66.a "tests" ""
echo ""
echo "Generating answer for test #67"
scripts/gen-answer.sh tests/67 tests/67.a "tests" ""
echo ""
echo "Generating answer for test #68"
scripts/gen-answer.sh tests/68 tests/68.a "tests" ""
echo ""
echo "Generating answer for test #69"
scripts/gen-answer.sh tests/69 tests/69.a "tests" ""
echo ""
echo "Generating answer for test #70"
scripts/gen-answer.sh tests/70 tests/70.a "tests" ""
echo ""
echo "Generating answer for test #71"
scripts/gen-answer.sh tests/71 tests/71.a "tests" ""
echo ""
echo "Generating answer for test #72"
scripts/gen-answer.sh tests/72 tests/72.a "tests" ""
echo ""
echo "Generating answer for test #73"
scripts/gen-answer.sh tests/73 tests/73.a "tests" ""
echo ""
echo "Generating answer for test #74"
scripts/gen-answer.sh tests/74 tests/74.a "tests" ""
echo ""
echo "Generating answer for test #75"
scripts/gen-answer.sh tests/75 tests/75.a "tests" ""
echo ""
echo "Generating answer for test #76"
scripts/gen-answer.sh tests/76 tests/76.a "tests" ""
echo ""
echo "Generating answer for test #77"
scripts/gen-answer.sh tests/77 tests/77.a "tests" ""
echo ""
echo "Generating answer for test #78"
scripts/gen-answer.sh tests/78 tests/78.a "tests" ""
echo ""
echo "Generating answer for test #79"
scripts/gen-answer.sh tests/79 tests/79.a "tests" ""
echo ""
echo "Generating answer for test #80"
scripts/gen-answer.sh tests/80 tests/80.a "tests" ""
echo ""
echo "Generating answer for test #81"
scripts/gen-answer.sh tests/81 tests/81.a "tests" ""
echo ""
echo "Generating answer for test #82"
scripts/gen-answer.sh tests/82 tests/82.a "tests" ""
echo ""
echo "Generating answer for test #83"
scripts/gen-answer.sh tests/83 tests/83.a "tests" ""
echo ""
echo "Generating answer for test #84"
scripts/gen-answer.sh tests/84 tests/84.a "tests" ""
echo ""
echo "Generating answer for test #85"
scripts/gen-answer.sh tests/85 tests/85.a "tests" ""
echo ""
echo "Generating answer for test #86"
scripts/gen-answer.sh tests/86 tests/86.a "tests" ""
echo ""
echo "Generating answer for test #87"
scripts/gen-answer.sh tests/87 tests/87.a "tests" ""
echo ""
echo "Generating answer for test #88"
scripts/gen-answer.sh tests/88 tests/88.a "tests" ""
echo ""
echo "Generating answer for test #89"
scripts/gen-answer.sh tests/89 tests/89.a "tests" ""
echo ""
echo "Generating answer for test #90"
scripts/gen-answer.sh tests/90 tests/90.a "tests" ""
echo ""
echo "Generating answer for test #91"
scripts/gen-answer.sh tests/91 tests/91.a "tests" ""
echo ""
echo "Generating answer for test #92"
scripts/gen-answer.sh tests/92 tests/92.a "tests" ""
echo ""
echo "Generating answer for test #93"
scripts/gen-answer.sh tests/93 tests/93.a "tests" ""
echo ""
echo "Generating answer for test #94"
scripts/gen-answer.sh tests/94 tests/94.a "tests" ""
echo ""
echo "Generating answer for test #95"
scripts/gen-answer.sh tests/95 tests/95.a "tests" ""
echo ""
echo "Generating answer for test #96"
scripts/gen-answer.sh tests/96 tests/96.a "tests" ""
echo ""
echo "Generating answer for test #97"
scripts/gen-answer.sh tests/97 tests/97.a "tests" ""
echo ""
echo "Generating answer for test #98"
scripts/gen-answer.sh tests/98 tests/98.a "tests" ""
echo ""
echo "Generating answer for test #99"
scripts/gen-answer.sh tests/99 tests/99.a "tests" ""
echo ""
echo "Generating answer for test #100"
scripts/gen-answer.sh tests/100 tests/100.a "tests" ""
echo ""
echo "Generating answer for test #101"
scripts/gen-answer.sh tests/101 tests/101.a "tests" ""
echo ""
echo "Generating answer for test #102"
scripts/gen-answer.sh tests/102 tests/102.a "tests" ""
echo ""
echo "Generating answer for test #103"
scripts/gen-answer.sh tests/103 tests/103.a "tests" ""
echo ""

#    *** pretests ***
mkdir -p pretests
echo "Generating test #5"
scripts/gen-input-via-stdout.sh "wine files/gen_rect_in_rect.exe 632 1 69" "pretests/05" 5
echo "Generating test #6"
scripts/gen-input-via-stdout.sh "wine files/gen_rect_in_rect.exe 632 10 69" "pretests/06" 6
echo "Generating test #7"
scripts/gen-input-via-stdout.sh "wine files/gen_rect_in_rect.exe 632 1000 69" "pretests/07" 7
echo "Generating test #8"
scripts/gen-input-via-stdout.sh "wine files/gen_L_shape.exe 632 1" "pretests/08" 8
echo "Generating test #9"
scripts/gen-input-via-stdout.sh "wine files/gen_L_shape.exe 632 10" "pretests/09" 9
echo "Generating test #10"
scripts/gen-input-via-stdout.sh "wine files/gen_L_shape.exe 632 1000 seed" "pretests/10" 10
echo "Generating test #11"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 5 80000 40 3" "pretests/11" 11
echo "Generating test #12"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 1 400000 40 3" "pretests/12" 12
echo "Generating test #13"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 1 400000 100 3" "pretests/13" 13
echo "Generating test #14"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 50 8000 100 3" "pretests/14" 14
echo "Generating test #15"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 632 632 100 3" "pretests/15" 15
echo "Generating test #16"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 400000 1 100 3" "pretests/16" 16
echo "Generating test #17"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 1 400000 0 3" "pretests/17" 17
echo "Generating test #18"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 632 632 0 3" "pretests/18" 18
echo "Generating test #19"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 1 50 1" "pretests/19" 19
echo "Generating test #20"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 1 97 1" "pretests/20" 20
echo "Generating test #21"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 2 50 1" "pretests/21" 21
echo "Generating test #22"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 3 20 1" "pretests/22" 22
echo "Generating test #23"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 3 50 1" "pretests/23" 23
echo "Generating test #24"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 3 97 1" "pretests/24" 24
echo "Generating test #25"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 632 632 5 50 1" "pretests/25" 25
echo "Generating test #26"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 3 50 1" "pretests/26" 26
echo "Generating test #27"
scripts/gen-input-via-stdout.sh "wine files/gen_top_shape.exe 5000 80 5 50 1" "pretests/27" 27
echo "Generating test #28"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 501 314 0 3" "pretests/28" 28
echo "Generating test #29"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 1 1 0 3" "pretests/29" 29
echo "Generating test #30"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 1 1 100 3" "pretests/30" 30
echo ""
echo "Generating answer for test #1"
scripts/gen-answer.sh pretests/01 pretests/01.a "pretests" ""
echo ""
echo "Generating answer for test #2"
scripts/gen-answer.sh pretests/02 pretests/02.a "pretests" ""
echo ""
echo "Generating answer for test #3"
scripts/gen-answer.sh pretests/03 pretests/03.a "pretests" ""
echo ""
echo "Generating answer for test #4"
scripts/gen-answer.sh pretests/04 pretests/04.a "pretests" ""
echo ""
echo "Generating answer for test #5"
scripts/gen-answer.sh pretests/05 pretests/05.a "pretests" ""
echo ""
echo "Generating answer for test #6"
scripts/gen-answer.sh pretests/06 pretests/06.a "pretests" ""
echo ""
echo "Generating answer for test #7"
scripts/gen-answer.sh pretests/07 pretests/07.a "pretests" ""
echo ""
echo "Generating answer for test #8"
scripts/gen-answer.sh pretests/08 pretests/08.a "pretests" ""
echo ""
echo "Generating answer for test #9"
scripts/gen-answer.sh pretests/09 pretests/09.a "pretests" ""
echo ""
echo "Generating answer for test #10"
scripts/gen-answer.sh pretests/10 pretests/10.a "pretests" ""
echo ""
echo "Generating answer for test #11"
scripts/gen-answer.sh pretests/11 pretests/11.a "pretests" ""
echo ""
echo "Generating answer for test #12"
scripts/gen-answer.sh pretests/12 pretests/12.a "pretests" ""
echo ""
echo "Generating answer for test #13"
scripts/gen-answer.sh pretests/13 pretests/13.a "pretests" ""
echo ""
echo "Generating answer for test #14"
scripts/gen-answer.sh pretests/14 pretests/14.a "pretests" ""
echo ""
echo "Generating answer for test #15"
scripts/gen-answer.sh pretests/15 pretests/15.a "pretests" ""
echo ""
echo "Generating answer for test #16"
scripts/gen-answer.sh pretests/16 pretests/16.a "pretests" ""
echo ""
echo "Generating answer for test #17"
scripts/gen-answer.sh pretests/17 pretests/17.a "pretests" ""
echo ""
echo "Generating answer for test #18"
scripts/gen-answer.sh pretests/18 pretests/18.a "pretests" ""
echo ""
echo "Generating answer for test #19"
scripts/gen-answer.sh pretests/19 pretests/19.a "pretests" ""
echo ""
echo "Generating answer for test #20"
scripts/gen-answer.sh pretests/20 pretests/20.a "pretests" ""
echo ""
echo "Generating answer for test #21"
scripts/gen-answer.sh pretests/21 pretests/21.a "pretests" ""
echo ""
echo "Generating answer for test #22"
scripts/gen-answer.sh pretests/22 pretests/22.a "pretests" ""
echo ""
echo "Generating answer for test #23"
scripts/gen-answer.sh pretests/23 pretests/23.a "pretests" ""
echo ""
echo "Generating answer for test #24"
scripts/gen-answer.sh pretests/24 pretests/24.a "pretests" ""
echo ""
echo "Generating answer for test #25"
scripts/gen-answer.sh pretests/25 pretests/25.a "pretests" ""
echo ""
echo "Generating answer for test #26"
scripts/gen-answer.sh pretests/26 pretests/26.a "pretests" ""
echo ""
echo "Generating answer for test #27"
scripts/gen-answer.sh pretests/27 pretests/27.a "pretests" ""
echo ""
echo "Generating answer for test #28"
scripts/gen-answer.sh pretests/28 pretests/28.a "pretests" ""
echo ""
echo "Generating answer for test #29"
scripts/gen-answer.sh pretests/29 pretests/29.a "pretests" ""
echo ""
echo "Generating answer for test #30"
scripts/gen-answer.sh pretests/30 pretests/30.a "pretests" ""
echo ""

