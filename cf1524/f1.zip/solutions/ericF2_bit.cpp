// slower sol with bit
#include <bits/stdc++.h>
#define all(x) (x).begin(), (x).end()

#define ONLINE_JUDGE

#ifndef ONLINE_JUDGE
template<typename T>
void pr(T a){std::cerr<<a<<std::endl;}
template<typename T,typename... Args>
void pr(T a, Args... args) {std::cerr<<a<<' ',pr(args...);}
#else
template<typename... Args>
void pr(Args... args){}
#endif

using namespace std;
constexpr int MM = 4e5+5;

vector<string> s;
vector<vector<int>> id;
vector<int> a, top;

int n, m, t;
int blue[MM];
vector<int> adj[MM];
vector<int> adjf[MM], adjr[MM];
bool ins[MM];
int path[MM], ptr, tt, dfn[MM], low[MM], sid[MM];

bool vis1[MM], dp1[MM];
bool vis2[MM];
array<int, 2> dp2[MM];

int bit[MM];
void up(int i, int v){
	for(i = t+1-i; i < MM; i += i&-i)
		bit[i] = min(bit[i], v);
}
int qu(int i){
	int v = 1e9;
	for(i = t+1-i; i; i -= i&-i)
		v = min(v, bit[i]);
	return v;
}

void dfs0(int cur){
			
	ins[cur] = 1;
	path[++ptr] = cur;
	dfn[cur] = low[cur] = ++tt;
	
	for(int u: adj[cur]){
		if(!dfn[u]){
			dfs0(u);
			low[cur] = min(low[cur], low[u]);
		}
		else if(ins[u])
			low[cur] = min(low[cur], dfn[u]);
	}
	
	if(dfn[cur] == low[cur]){
		int u = -1;
		while(u != cur){
			u = path[ptr--];
			ins[u] = 0;
			sid[u] = cur;
			blue[cur] |= blue[u];
		}
	}
}

bool dfs1(int cur){
	if(vis1[cur]) return dp1[cur];
	vis1[cur] = 1;
	for(int u: adjr[cur]){
		assert(u != cur);
		//reversed adj (upwards)
		dp1[cur] |= blue[u] | dfs1(u);
	}
	// pr("cur", cur);
	// for(int u: adjr[cur]){
		// pr("u", u);
	// }
	// pr("dfs1", cur, dp1[cur], blue[cur]);
	return dp1[cur];
}

array<int, 2> dfs2(int cur){
	if(vis2[cur]) return dp2[cur];
	vis2[cur] = 1;

	for(int u: adjf[cur]){
		assert(u != cur);
		auto ret = dfs2(u);
		dp2[cur] = {min(dp2[cur][0], ret[0]), max(dp2[cur][1], ret[1])};
	}
	// pr("dfs2", cur, dp2[cur][0], dp2[cur][1]);
	return dp2[cur];
}

int main(){
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cin.exceptions(cin.failbit);
	
	cin>>n>>m;
	a.resize(m+2);
	top.resize(m+2);
	id.resize(n+2);
	s.resize(n+2);
	for(auto &i: id)
		i.resize(m+2);

	for(int i = n; i; i--)
		cin>>s[i];
	for(int i = 1; i <= m; i++)
		cin>>a[i];

	//so that lower # nodes are on left
	for(int j = 1; j <= m; j++){
		for(int i = 1; i <= n; i++){
			if(s[i][j-1] == '#')
				id[i][j] = ++t;
		}
	}

	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= m; j++){
			if(id[i][j]){
				int cur = id[i][j];
				if(!--a[j])
					blue[cur] = 1;

				auto addedge = [](int a, int b){
					if(a == b) return;
					adj[a].emplace_back(b);
					// adjf[a].emplace_back(b);
					// adjr[b].emplace_back(a);
				};

				if(top[j-1]) addedge(cur, top[j-1]);
				if(top[j]) addedge(cur, top[j]);
				if(top[j+1]) addedge(cur, top[j+1]);

				//directly connected
				if(id[i-1][j])
					addedge(id[i-1][j], cur);
				if(id[i][j-1])
					addedge(id[i][j-1], cur);

				top[j] = id[i][j];
			}
		}
	}

	for(int j = 1; j <= m; j++){
		if(a[j] > 0){
			cout<<"-1\n";
			return 0;
		}
	}

	for(int i = 1; i <= t; i++){
		if(!dfn[i]){
			dfs0(i);
		}
	}

	// for(int i = 1; i <= n; i++){
	// 	for(int j = 1; j <= m; j++){
	// 		string ss = to_string(id[i][j])+"  ";
	// 		cout<<ss.substr(0, 3);
	// 	}
	// 	cout<<endl;
	// }

	auto addedge = [](int a, int b){
		if(a == b) return;
		adjf[a].emplace_back(b);
		adjr[b].emplace_back(a);
	};

	for(int cur = 1; cur <= t; cur++){
		for(int u: adj[cur]){
			if(sid[cur] != sid[u]){
				addedge(sid[cur], sid[u]);
			}
		}
	}

	for(int i = 1; i <= t; i++){
		if(sid[i] != i) continue;
		if(!vis1[i]){
			dfs1(i);
		}
	}
	//good ones are blue and dp1[cur] = 0

	for(int i = 1; i <= t; i++){
		if(sid[i] != i) continue;
		dp2[i] = {INT_MAX/3, -1};
		if(blue[i]){
			// pr("i", i, dp1[i]);
			if(!dp1[i])
				dp2[i] = {i, i};
		}
		sort(all(adjf[i]));
	}
	vector<array<int, 2>> v;

	for(int i = 1; i <= t; i++){
		if(sid[i] != i) continue;
		if(!vis2[i]){
			dfs2(i);
		}
		if(!size(adjr[i])){
			//also works without this if statement
			//top node, insert it
			pr("seg", i, dp2[i][0], dp2[i][1]);
			if(dp2[i][1] != -1){
				v.emplace_back(dp2[i]);
			}
		}
	}
	sort(all(v), [](auto x, auto y){
		if(x[0] == y[0])
			return x[1] > y[1];
		return x[0] < y[0];
	});

	vector<int> dp(t+1, 9);
	dp[0] = 0;
	vector<int> rs[t+1];
	for(auto [a, b]: v){
		rs[a-1].push_back(b);
	}

	memset(bit, 0x3f, sizeof bit);

	for(int i = 0; i <= t; i++){
		dp[i] = qu(i);
		if(i == 0){
			dp[0] = 0;
		}
		else if(sid[i] == i and blue[i] and !dp1[i]){
			// cout<<"no "<<i<<endl;
		}
		else{
			dp[i] = min(dp[i], dp[i-1]);
		}
		for(auto j: rs[i]){
			up(j, dp[i]+1);
		}
		// cerr<<dp[i]<<' ';
	}
	// cerr<<endl;

	cout<<dp[t]<<'\n';
}
/*
floodfill nodes
colour blue the nodes that need to be taken
"prune" the blue nodes by only "keeping" the blue nodes that have no blue ancestors
the blue nodes are all leaves
then, dp for ls and rs of subtree[i]
insert the segments for top nodes
greedy
*/