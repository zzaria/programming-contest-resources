#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;
using ll = long long;

const int MN = 1e5 + 1;
int N, A, B;
vector<int> g[MN];

int pathNode[MN];
void dfs(int c, int p, int pnode) {
    if (pathNode[c] != -1) return;
    pathNode[c] = pnode;
    for (auto to : g[c])
        if (to != p)
            dfs(to, c, pnode);
}
bool getPath(int c, int p, int end) {
    if (c == end) {
        pathNode[c] = c;
        for (auto to : g[c])
            if (to != p)
                dfs(to, -1, c);
        return true;
    }

    bool onPath = false;
    for (auto to : g[c])
        if (to != p)
            onPath |= getPath(to, c, end);
    if (onPath) {
        pathNode[c] = c;
        for (auto to : g[c])
            if (to != p)
                dfs(to, -1, c);
    }
    return onPath;
}

// endl flushes right????
int main(int argc, char *argv[]) {
    registerInteraction(argc, argv);

    // get input and output tree to user
    N = inf.readInt();
    cout << N << '\n';
    for (auto i = 0; i < N-1; i++) {
        int a = inf.readInt(), b = inf.readInt();
        g[a].push_back(b);
        g[b].push_back(a);
        cout << a << ' ' << b << '\n';
    }
    cout.flush();
    // read hidden nodes
    A = inf.readInt(); B = inf.readInt();
    if (A > B) swap(A, B);
    // read extra "hint" node on path
    int F = inf.readInt();

    // get user K
    int user_K = ouf.readInt(0, N), queriesLeft = user_K;
    // output F
    cout << F << endl;

    // precalc ans
    fill(pathNode+1, pathNode+N+1, -1);
    getPath(A, -1, B);

    // begin interaction
    string s = ouf.readWord();
    while (true) {
        if (s == "!") {
            int user_A = ouf.readInt(1, N), user_B = ouf.readInt(1, N);
            if (user_A > user_B) swap(user_A, user_B);
            if (A != user_A || B != user_B) quitf(_wa, "expected A=%d B=%d user gave A=%d B=%d", A, B, user_A, user_B);
            tout << user_K << '\n';
            quitf(_ok, "processed %d queries", user_K-queriesLeft);
            return 0;
        }
        else if (s == "?") {
            if (queriesLeft == 0) quitf(_wa, "participant answered %d queries required but tried to use more queries", user_K);
            int user_R = ouf.readInt(1, N);
            cout << pathNode[user_R] << '\n'; cout.flush();

            queriesLeft--;
        }
        else
            quitf(_wa, "invalid query type %s", s.c_str());

        s = ouf.readWord();
    }
}

