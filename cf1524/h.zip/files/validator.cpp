#include "testlib.h"
#include "bits/stdc++.h"
using namespace std;

const int MN = 1e5 + 1;
int dsu[MN];
int rt(int x) { return dsu[x] == x ? x : dsu[x] = rt(dsu[x]); }
vector<int> g[MN];

set<int> path;
bool getPath(int c, int p, int end) {
    if (c == end) {
        path.insert(c);
        return true;
    }
    bool ok = false;
    for (auto to : g[c]) {
        if (to != p) {
            ok |= getPath(to, c, end);
        }
    }
    if (ok) path.insert(c);
    return ok;
}

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);
    int N = inf.readInt(1, 100000, "N");
    inf.readEoln();

    iota(dsu, dsu+MN, 0);
    for (auto i = 0; i < N-1; i++) {
        int a = inf.readInt(1, N, "a_" + to_string(i));
        inf.readSpace();
        int b = inf.readInt(1, N, "b_" + to_string(i));
        inf.readEoln();

        ensuref(rt(a) != rt(b), "edge %d to %d creates cycle", a, b);
        dsu[rt(b)] = rt(a);

        g[a].push_back(b);
        g[b].push_back(a);
    }

    // A and B can equal
    int A = inf.readInt(1, N, "A");
    inf.readSpace();
    int B = inf.readInt(1, N, "B");
    inf.readEoln();
    // extra node "onpath"
    int F = inf.readInt(1, N, "F"); inf.readEoln();
    getPath(A, -1, B);
    ensuref(path.count(F), "hint node %d not on path from A=%d to B=%d", F, A, B);

    inf.readEof();
}

