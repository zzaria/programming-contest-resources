from sys import stdin, stdout, setrecursionlimit, exit
input = stdin.readline
flush = stdout.flush
gi = lambda: list(map(int, input().split()))

MOD = 10**9 + 7
def solve():
    N = int(input())
    A = gi()
    B = gi()
    adj = [[] for i in range(N + 1)]
    for a, b in zip(A, B):
        adj[a].append(b)
        adj[b].append(a)
    if any(len(i) > 2 for i in adj):
        print(0)
        return
    tot = 1
    vis = [0] * (N + 1)
    for i in range(1, N + 1):
        if vis[i]: continue
        queue = [i]
        vis[i] = 1
        for node in queue:
            for nx in adj[node]:
                if vis[nx]: continue
                vis[nx] = 1
                queue.append(nx)
        tot *= 2
        tot %= MOD
    print(tot)

T = int(input())
for _ in range(T): solve()