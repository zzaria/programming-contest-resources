#include <bits/stdc++.h>

using namespace std;

const int MAXN = 400005;
const int MOD = 1000000007;

bool vis[MAXN];
bool has[MAXN];
vector<int> missing_by_val[MAXN];
vector<int> missing_by_ind[MAXN];

int main()
{
    int t;
    scanf("%i", &t);
    while (t--)
    {
        int n;
        scanf("%i", &n);
        for (int x = 0; x <= n; x++)
        {
            vis[x] = has[x] = 0;
            missing_by_val[x].clear();
            missing_by_ind[x].clear();
        }
        int a;
        for (int y = 0; y < 2; y++)
        {
            for (int x = 1; x <= n; x++)
            {
                scanf("%i", &a);
                missing_by_val[a].push_back(x);
                missing_by_ind[x].push_back(a);
            }
        }
        int cnt = 0;
        for (int y = 1; y <= n; y++)
        {
            if (!vis[y])
            {
                cnt++;
                queue<int> buf;
                buf.push(y);
                vis[y] = 1;
                while (!buf.empty())
                {
                    int u = buf.front();
                    buf.pop();
                    for (auto &v : missing_by_ind[u])
                        for (auto &x : missing_by_val[v])
                            if (!vis[x])
                                buf.push(x), vis[x] = 1;
                }
            }
        }
        int ans = 1;
        while (cnt--)
            ans = (ans << 1) % MOD;
        printf("%i\n", ans);
    }
}
