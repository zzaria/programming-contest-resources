import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.TreeSet;

public class C {
	static final long MOD = 1000000007;

	public static void main(String[] args) throws IOException {
		int T = readInt();
		while (T-- > 0) {
			int n = readInt();
			DSU d = new DSU(n);
			
			int[] a = new int[n], b = new int[n];
			for (int i = 0; i < n; i++) a[i] = readInt();
			for (int i = 0; i < n; i++) b[i] = readInt();
			long ans = 1;
			for (int i = 0; i < n; i++) d.unite(a[i], b[i]);
			TreeSet<Integer> ts = new TreeSet<>();
			for (int i = 1; i <= n; i++) {
				int r = d.rt(i);
				if (!ts.contains(r)) {
					ts.add(r);
					ans = (ans * 2) % MOD;
				}
			}
			System.out.println(ans);
		}
	}
	
	static class DSU {
		int n, dsu[];
		DSU(int n0) {
			n = n0;
			dsu = new int[n+1];
			for (int i = 0; i <= n; i++) dsu[i] = i;
		}
		int rt(int x) {
			if (x == dsu[x]) return x;
			dsu[x] = rt(dsu[x]);
			return dsu[x];
		}
		void unite(int x, int y) { dsu[rt(y)] = rt(x); }
	}
	
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
    static String next() throws IOException {
    	while (st == null || !st.hasMoreTokens()) st = new StringTokenizer(br.readLine().trim());
    	return st.nextToken();
    }
    static long readLong() throws IOException {
    	return Long.parseLong(next());
	}
    static int readInt() throws IOException {
    	return Integer.parseInt(next());
    }
    static short readShort() throws IOException{
    	return Short.parseShort(next());
    }
    static double readDouble() throws IOException {
        return Double.parseDouble(next());
    }
    static char readCharacter() throws IOException {
        return next().charAt(0);
    }
    static String readLine() throws IOException {
        return br.readLine().trim();
    }
}
