#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using pii = pair<int, int>;

int cycle_t;

vector<int> makeArr(int n, int sum, int req) {
    vector<int> res(n, req);
    sum -= n*req;
    vector<int> p{0};
    for (auto i = 0; i < n-1; i++)
        p.push_back(rnd.next(0, sum));
    p.push_back(sum);
    sort(p.begin(), p.end());
    for (auto i = 0; i < n; i++)
        res[i] += p[i+1]-p[i];
    return res;
}

vector<int> perm(int n) {
    vector<int> res(n);
    iota(res.begin(), res.end(), 1);
    shuffle(res.begin(), res.end());
    return res;
}

void make(int n) {
    cout << (n) << '\n';

    auto p = perm(n);
    vector<pii> es;
    int cur = 0, cycleCnt = rnd.wnext(1, n/2, cycle_t);
    for (auto len : makeArr(cycleCnt, n, 2)) {
        for (auto i = cur; i < cur+len; i++)
            es.emplace_back(i, i+1 == cur+len ? cur : i+1);
        cur += len;
    }
    shuffle(es.begin(), es.end());
    for (auto i = 0; i < n; i++) cout << p[es[i].first] << " \n"[i == n-1];
    for (auto i = 0; i < n; i++) cout << p[es[i].second] << " \n"[i == n-1];
}

int main(int argc, char *argv[]) {
    registerGen(argc, argv, 1);

    int tc = stoi(argv[1]), totN = stoi(argv[2]);
    cycle_t = stoi(argv[3]);
    assert(tc <= totN);

    cout << tc << '\n';
    for (auto n : makeArr(tc, totN, 2))
        make(n);
}
