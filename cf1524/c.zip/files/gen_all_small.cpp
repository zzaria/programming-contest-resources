#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;
using ll = long long;

const int MV = 5, MN = 101;
int a[MN];
void rec(int c, int n) {
    if (c == n) {
        cout << (n) << '\n';
        for (auto i = 0; i < n; i++) cout << a[i] << " \n"[i == n-1];
        return;
    }

    for (auto i = 0; i <= MV; i++) {
        a[c] = i;
        rec(c+1, n);
    }
}

int der(int n) {
    int p[n], res = 0; iota(p, p+n, 0);
    do {
        bool ok = true;
        for (auto i = 0; i < n; i++) ok &= i != p[i];
        res += ok;
    } while (next_permutation(p, p+n));
    return res;
}
int fact(int n) { return n == 0 ? 1 : n*fact(n-1); }

int main(int argc, char *argv[]) {
    registerGen(argc, argv, 1);

    int lim = atoi(argv[1]), tc = 0;
    for (auto i = 1; i <= lim; i++)
        tc += fact(i)*der(i);

    cout << (tc) << '\n';
    for (auto n = 1; n <= lim; n++) {
        int a[n]; iota(a, a+n, 0);
        do {
            int b[n]; iota(b, b+n, 0);
            do {
                bool ok = true;
                for (auto i = 0; i < n; i++) ok &= a[i] != b[i];
                if (ok) {
                    cout << (n) << '\n';
                    for (auto j = 0; j < n; j++) cout << a[j]+1 << " \n"[j == n-1];
                    for (auto j = 0; j < n; j++) cout << b[j]+1 << " \n"[j == n-1];
                }
            } while (next_permutation(b, b+n));
        } while (next_permutation(a, a+n));
    }
}
