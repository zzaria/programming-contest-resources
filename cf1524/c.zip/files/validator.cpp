#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

const int LIMN = 400000, LIMSUMN = LIMN, LIMT = 10000;
int main(int argc, char* argv[]) {
    registerValidation(argc, argv);
    int T = inf.readInt(1, LIMT, "number of test cases");
    inf.readEoln();
    int sumN = 0;
    for (auto tc = 1; tc <= T; tc++) {
        setTestCase(tc);

        int N = inf.readInt(2, LIMN, "N"); sumN += N;
        inf.readEoln();

        vector<int> a(N), b(N);
        for (auto i = 0; i < N; i++) {
            a[i] = inf.readInt(1, N, "a_i");
            if (i == N-1) inf.readEoln();
            else inf.readSpace();
        }
        for (auto i = 0; i < N; i++) {
            b[i] = inf.readInt(1, N, "b_i");
            if (i == N-1) inf.readEoln();
            else inf.readSpace();
        }

        for (auto i = 0; i < N; i++) ensuref(a[i] != b[i], "column %d has same numbers %d", i, a[i]);
        set<int> vals;
        for (auto j = 0; j < N; j++) vals.insert(a[j]);
        ensuref(vals.size() == a.size(), "first row is not permutation");
        vals.clear();
        for (auto j = 0; j < N; j++) vals.insert(b[j]);
        ensuref(vals.size() == b.size(), "second row is not permutation");

        ensuref(sumN <= LIMSUMN, "Sum of N must be at most %d", LIMSUMN);
    }
    inf.readEof();
}
