#include <bits/stdc++.h>
//#pragma GCC optimize("Ofast")
#define fori(a,b) for(int i=a;i<b;i++)
#define forj(a,b) for(int j=a;j<b;j++)
#define fork(a,b) for(int k=a;k<b;k++)
#define ford(i,a,b) for(int i=a;i>=b;i--)
#define seto(x,i) memset(x,i,sizeof x)
#define inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f
#define pf first
#define ps second
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;

const int N=1010,L=18;
vector<pii> gr[N];
int n,q,a,b,c,d,dist[N][N];
ll x,y,dp[2];

void dfs(int v,int p)
{
    for(auto i:gr[v])
        if(i.pf!=p)
        {
            dist[a][i.pf]=dist[a][v]+i.ps;
            dfs(i.pf,v);
        }
}
int dlen(int aa,int bb)
{
    return dist[aa][bb];
}

int main()
{
    cin.sync_with_stdio(0);
    cin.tie(0);
    freopen("in4.txt","r",stdin);
    //freopen("out1c.txt","w",stdout);
    cin>>n>>q;
    fori(1,n)
    {
        cin>>a>>b>>c;
        gr[a].push_back({b,c}); gr[b].push_back({a,c});
    }
    fori(1,n)
    {
        a=i;
        dfs(1,1);
    }
    fori(0,q)
    {
        cin>>a>>b;
        x=min(dp[0]+dlen(b,c),dp[1]+dlen(b,d));
        y=min(dp[0]+dlen(a,c),dp[1]+dlen(a,d));
        dp[0]=x+dlen(a,b); dp[1]=y+dlen(a,b); c=a; d=b;
    }
    cout<<min(dp[0],dp[1])<<endl;
    return 0;
}
