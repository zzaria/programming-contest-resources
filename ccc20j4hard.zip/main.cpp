#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <cmath>
#include <unordered_set>
typedef long long ll;
using namespace std;
ll read() {
    ll cur;
    cin >> cur;
    return cur;
}

ll m = 61605403707;

string stack;
string needle;

const ll NN = 200005;
ll p[NN+1];
ll pr = 31;

multiset<ll> shifts;

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    p[0] = 1;
    for(int i=1;i<=NN;i++) p[i] = (p[i-1]*pr)%m;

    cin >> stack >> needle;
    ll nedHash = 0;
    for(int i=0;i<needle.size();i++) nedHash = (nedHash+((needle[i]-'A')*p[i])%m)%m;
    for(ll ri=needle.size()-1;ri>=0;ri--){
        shifts.insert(nedHash);
        //cout << nedHash << endl;
        nedHash = (((nedHash-((needle[ri]-'A')*p[needle.size()-1])%m)%m)+m)%m;
        nedHash = (nedHash*pr)%m;
        nedHash = (nedHash+(needle[ri]-'A'))%m;
    }

    ll winHash = 0;
    for(int i=stack.size()-needle.size(),v=0;i<stack.size();i++,v++) winHash = (winHash+((stack[i]-'A')*p[v])%m)%m;
    winHash = (((winHash-(stack[stack.size()-needle.size()]-'A')%m)%m)+m)%m;

    //cout << endl;

    //cout << winHash << endl;

    //cout << endl;

    for(ll r=stack.size()-1,l=stack.size()-needle.size();l>=0;l--,r--){
        winHash = (winHash+(stack[l]-'A'))%m;

        //cout << winHash << endl;
        /*
        ll bl = 0;
        ll br = shifts.size()-1;
        if(winHash < shifts[bl] || winHash > shifts[br]);
        else{
            while(bl < br){
                cout << " " << bl << "-" << br << endl;
                ll mid = (bl+br)/2;
                if(shifts[mid] == winHash) {
                    cout << "yes" << endl;
                    return 0;
                } else if(shifts[mid] < winHash) bl = mid+1;
                else if(shifts[mid] > winHash) br = mid-1;
            }
        }*/

        if(shifts.find(winHash) != shifts.end()){
            cout << "yes" << endl;
            return 0;
        }

        winHash = (((winHash-((stack[r]-'A')*p[needle.size()-1])%m)%m)+m)%m;
        winHash = (winHash*pr)%m;
    }

    cout << "no" << endl;

    return 0;
}
